#include "cachelab.h"
#include <unistd.h>
#include <getopt.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct {
    int valid;
    int tag;
    int time_stamp;
} cache_block;
cache_block **cache=NULL;

int hit=0,miss=0,eviction=0,s,E,b,S;

void print_help(){
    printf("No help\n");
}

void operate(int tg,int set){
    int max_time = -1;
    int max_j = -1;
    for(int j=0; j < E;j++)
        if(cache[set][j].valid==1 && cache[set][j].tag == tg){
            hit++;
            cache[set][j].time_stamp = 0;
            return;
        }
    for(int j=0; j < E;j++)
        if(cache[set][j].valid == 0){
            cache[set][j].tag = tg;
            cache[set][j].valid=1;
            cache[set][j].time_stamp=0;
            miss++;
            return;
        }
    for(int j=0; j < E;j++)
        if(cache[set][j].time_stamp > max_time){
            max_time = cache[set][j].time_stamp;
            max_j = j;
        }
    eviction++;
    miss++;
    cache[set][max_j].tag = tg;
    cache[set][max_j].time_stamp=0;
    return;
}


void read_trace(char* t){
    FILE* fp = fopen(t, "r");
	if(fp == NULL)
	{
		printf("Can't open file\n");
		return ;
	}
    char op;
    unsigned addr;
    int size;
    while(fscanf(fp, " %c %x,%d\n", &op, &addr, &size) > 0)
	{
		int now_tag = addr >> (s + b);
        int now_s = (addr >> b) & ((-1U) >> (64 - s));
		switch(op)
		{
			case 'I': 
                continue;			
            case 'M':
				operate(now_tag,now_s);  
                operate(now_tag,now_s);
				break;
			case 'L':
				operate(now_tag,now_s);
				break;
			case 'S':
				operate(now_tag,now_s);
                break;
        }
		for(int i=0; i < S; i++)
		    for(int j=0; j < E; j++)
			    if(cache[i][j].valid== 1)
				    cache[i][j].time_stamp++;
	}
    fclose(fp);
}

int main(int argc, char* argv[])
{
	char opt; 
    char trace[2024]={0}; 
	while(-1 != (opt = (getopt(argc, argv, "hvs:E:b:t:")))){
		switch(opt){
			case 's':
				s = atoi(optarg);
				break;
			case 'E':
				E = atoi(optarg);
				break;
			case 'b':
				b = atoi(optarg);
				break;
			case 't':
				strcpy(trace, optarg);
				break;
			default:
				print_help();
				break;
		}
	}
	
	if(s<=0 || E<=0 || b<=0 || trace[0]==0){
        printf("wrong cache!\n");
        return -1;
    }
	S = 1 << s;               
		
    cache = (cache_block **)malloc(S * sizeof(cache_block *));
    if (cache == NULL) {
        printf("malloc failed\n");
        return -1;
    }
    for (int i = 0; i < S; i++) {
        cache[i] = (cache_block *)malloc(E * sizeof(cache_block));
        for(int j = 0; j < E; ++j)
		{
			cache[i][j].valid = 0;
			cache[i][j].tag = -1;
			cache[i][j].time_stamp = -1;
		}
        if (cache[i] == NULL) {
            printf("malloc failed\n");
            return -1;
        } 
    }

	read_trace(trace); 

    for (int i = 0; i < S; i++) {
        free(cache[i]);
    }
    free(cache);

    printSummary(hit, miss, eviction);
    
    return 0;
}